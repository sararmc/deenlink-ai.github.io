# DeenLink AI — v1.2.1 (PWA 0€)
## Nouveautés
- 🖼️ Bannière sombre “Ressources authentiques” intégrée (1920×600)
- 🛍️ Ressources affiliées (Amazon tag: deenlinkai-21, OneLink actif)
- 🌙 Modules: Défi 100 jours, Deen Tools, Productivité, PDF, Contact

## Déploiement (GitHub Pages)
1. Repo public → upload tous les fichiers de ce dossier.
2. Settings → Pages → Deploy from a branch (main).
3. Ouvre l’URL et “Ajouter à l’écran d’accueil”.

## Personnalisation
- Remplace l’image dans /banners/ si tu veux une autre.
- Modifie les requêtes Amazon dans `index.html` si besoin.
